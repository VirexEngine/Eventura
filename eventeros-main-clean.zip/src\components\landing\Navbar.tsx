import { useState } from "react";
import { Link } from "react-router-dom";
import { motion, AnimatePresence } from "framer-motion";
import { Menu, X, Zap } from "lucide-react";
import { Button } from "@/components/ui/button";

const navLinks = [
  { label: "Events", href: "#events" },
  { label: "Features", href: "#features" },
  { label: "Leaderboard", href: "#leaderboard" },
];

export const Navbar = () => {
  const [mobileOpen, setMobileOpen] = useState(false);

  return (
    <motion.nav
      initial={{ y: -20, opacity: 0 }}
      animate={{ y: 0, opacity: 1 }}
      transition={{ duration: 0.6 }}
      className="fixed top-0 left-0 right-0 z-50"
    >
      <div className="mx-4 mt-3">
        <div className="bg-card/40 backdrop-blur-xl border border-border/30 rounded-2xl shadow-[0_4px_30px_-5px_hsl(0_0%_0%/0.5)]">
          <div className="container mx-auto flex items-center justify-between h-14 px-5">
            <Link to="/" className="flex items-center gap-2.5">
              <motion.div
                whileHover={{ rotate: 180, scale: 1.1 }}
                transition={{ duration: 0.4 }}
                className="w-8 h-8 rounded-lg bg-gradient-to-br from-primary to-accent flex items-center justify-center shadow-[0_0_15px_hsl(var(--primary)/0.4)]"
              >
                <Zap className="w-4 h-4 text-primary-foreground" />
              </motion.div>
              <span className="font-bold text-lg tracking-tight">EventOS</span>
            </Link>

            <div className="hidden md:flex items-center gap-1">
              {navLinks.map((link) => (
                <motion.a
                  key={link.label}
                  href={link.href}
                  whileHover={{ y: -1 }}
                  className="text-sm text-muted-foreground hover:text-foreground transition-colors px-3 py-1.5 rounded-lg hover:bg-secondary/50"
                >
                  {link.label}
                </motion.a>
              ))}
            </div>

            <div className="hidden md:flex items-center gap-1">
              <motion.div whileHover={{ scale: 1.05 }} whileTap={{ scale: 0.97 }}>
                <Link to="/login">
                  <Button variant="ghost" size="sm" className="text-muted-foreground hover:text-foreground text-xs">
                    Login
                  </Button>
                </Link>
              </motion.div>
            </div>

            <button className="md:hidden text-foreground" onClick={() => setMobileOpen(!mobileOpen)}>
              {mobileOpen ? <X className="w-5 h-5" /> : <Menu className="w-5 h-5" />}
            </button>
          </div>

          <AnimatePresence>
            {mobileOpen && (
              <motion.div
                initial={{ height: 0, opacity: 0 }}
                animate={{ height: "auto", opacity: 1 }}
                exit={{ height: 0, opacity: 0 }}
                className="md:hidden overflow-hidden border-t border-border/30"
              >
                <div className="p-4 flex flex-col gap-2">
                  {navLinks.map((link) => (
                    <a key={link.label} href={link.href} className="text-sm text-muted-foreground py-2 px-3 rounded-lg hover:bg-secondary/50">{link.label}</a>
                  ))}
                  <div className="border-t border-border/30 pt-2 mt-1">
                    <Link to="/login">
                      <button className="text-sm text-primary py-2 px-3 rounded-lg hover:bg-primary/10 w-full text-left">
                        Login →
                      </button>
                    </Link>
                  </div>
                </div>
              </motion.div>
            )}
          </AnimatePresence>
        </div>
      </div>
    </motion.nav>
  );
};
