import { Navbar } from "@/components/landing/Navbar";
import { HeroSection } from "@/components/landing/HeroSection";
import { FeaturesSection } from "@/components/landing/FeaturesSection";
import { LiveEventsSection } from "@/components/landing/LiveEventsSection";
import { LeaderboardSection } from "@/components/landing/LeaderboardSection";
import { Footer } from "@/components/landing/Footer";

const Index = () => {
  return (
    <div className="min-h-screen bg-background">
      <Navbar />
      <HeroSection />
      <LiveEventsSection />
      <FeaturesSection />
      <LeaderboardSection />
      <Footer />
    </div>
  );
};

export default Index;
